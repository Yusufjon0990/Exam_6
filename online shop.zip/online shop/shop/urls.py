from django.contrib import admin
from django.urls import path

from shop.views import product_list, product_detail, add_comment

urlpatterns = [
    path('', product_list, name='products'),
    path('category/<slug:category_slug>/products', product_list, name='products_of_category'),
    path('product/<slug:slug>', product_detail, name='product_detail'),

    # Comment urls
    path('product/<slug:product_slug>/detail/add-comment/',add_comment,name='add_comment' )
    # add product
    path('product-add/', product_add, name='product_add'),
    path('detail/<int:product_id>/comment', comment_add, name='comment_add'),
    path('detail/<int:pk>/order', order_add, name='order_add'),

    

    path('detail/<int:pk>/delete-product', delete_prt, name='delete'),
    path('detail/<int:pk>/edit-product', edit_prt, name='edit')
]


